const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin');
console.log(process.env.NODE_ENV)
module.exports = {
    entry: ['@babel/polyfill', "./src/index.ts"],
  
    devServer: {
        static: {
            directory: path.join(__dirname, 'public'),
        },
        compress: true,
        port: 9000,
        hot: true
    },
    output: {
        filename: "bundle.js"
    },
    resolve: {
        extensions: [".webpack.js", ".web.js", ".ts", ".tsx", ".js"]
    },
    module: {
        rules: [

            {
                test: /\.m?js$/,
                exclude: /node_modules/,
                use: {
                  loader: "babel-loader",
                  options: {
                    presets: ['@babel/preset-env']
                  }
                }
              } ,{
                test: /\.ts?$/, loader: "ts-loader"
            }
        ]
    },
    plugins: [new HtmlWebpackPlugin({
        title: '', filename: 'index.html',
        template: path.resolve(__dirname, './index.html'),
    })],
    // mode:"development"
    mode: "production"
};