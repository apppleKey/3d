import * as THREE from 'three';
import { SplineCurve } from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer'

let camara: THREE.PerspectiveCamera, scene: THREE.Scene, renderer: THREE.WebGLRenderer, labelRender: CSS2DRenderer, moonLabel: CSS2DObject;
let moon: THREE.Mesh, earth: THREE.Mesh;
//时钟
let clock = new THREE.Clock();
//纹理加载器
const textureLoader = new THREE.TextureLoader()
function init() {
    const EARTH_RADIUS = 2.5;
    const MOON_RADIUS = 0.6;
    camara = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 2000)
    camara.position.set(10, 5, 20);

    scene = new THREE.Scene();

    //点光源
    const dirLight = new THREE.SpotLight(0xffffff);
    dirLight.position.set(0, 0, 10);
    dirLight.intensity = 0.6;//强度
    dirLight.castShadow = true;//阴影
    scene.add(dirLight);

    // 环境光
    const aLight = new THREE.AmbientLight(0xffffff)
    aLight.intensity = 0.5;//强度
    aLight.castShadow = true;//阴影
    scene.add(aLight);

    const squeceometry=new THREE.PlaneGeometry(1.5,1.5,1.5)
    const squeMaterial=new THREE.MeshPhongMaterial({map: textureLoader.load('/ball.png')})
    const sque = new THREE.Mesh(squeceometry, squeMaterial);
    sque.position.set(0, 0, 10);
    scene.add(sque);

    //月球
    const moonCeometry = new THREE.SphereGeometry(MOON_RADIUS, 16, 16);
    const moonMaterial = new THREE.MeshPhongMaterial({ map: textureLoader.load('/ball.png') });
    moon = new THREE.Mesh(moonCeometry, moonMaterial);
    moon.receiveShadow = true;
    moon.castShadow = true;
    scene.add(moon);

    // 月球标签
    const moonDiv = document.createElement('div')
    moonDiv.className = "label";
    moonDiv.textContent = "Moon";
    moonLabel = new CSS2DObject(moonDiv);
    moon.add(moonLabel)
    moonLabel.position.set(0, MOON_RADIUS, 0)

    // 地球
    const earthCeometry = new THREE.SphereGeometry(EARTH_RADIUS, 16, 16);
    const earthMaterial = new THREE.MeshPhongMaterial({
        shininess: 5,//镜面反射程度
        map: textureLoader.load('/ball.jpg')
    });
    earth = new THREE.Mesh(earthCeometry, earthMaterial);
    earth.receiveShadow = true;//接收阴影
    earth.castShadow = true;//
    scene.add(earth);

    // 地球标签
    const earthDiv = document.createElement('div')
    earthDiv.className = "label";
    earthDiv.textContent = "Earth";
    const earthLabel = new CSS2DObject(earthDiv);
    earth.add(earthLabel)
    earthLabel.position.set(0, EARTH_RADIUS, 0)

    // 标签渲染器
    labelRender = new CSS2DRenderer();
    labelRender.setSize(window.innerWidth, window.innerHeight);
    labelRender.domElement.style.top = '0'
    labelRender.domElement.style.position = 'absolute'
    document.body.appendChild(labelRender.domElement)
    scene.add(earth)

    //渲染器
    renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio)
    renderer.setSize(window.innerWidth, window.innerHeight)
    // renderer.setClearColor(0xfffffF)

    //坐标系
    var axes = new THREE.AxesHelper(20);
    scene.add(axes);

    //阴影
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement)

    const controls = new OrbitControls(camara, renderer.domElement)
}

function animate() {
    const elapsed = clock.getElapsedTime();
    moon.position.set(Math.sin(elapsed) * 5, 0, Math.cos(elapsed) * 5);

    var axis = new THREE.Vector3(0, 1, 0);
    earth.rotateOnAxis(axis, 0.01);
    renderer.render(scene, camara);
    labelRender.render(scene, camara)
    requestAnimationFrame(animate);

}
init()
animate()
window.onresize = function () {
    camara.aspect = window.innerWidth / window.innerHeight;
    camara.updateProjectionMatrix()
    renderer.setSize(window.innerWidth, window.innerHeight)
}